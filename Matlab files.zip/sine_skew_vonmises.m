function Y = sine_skew_vonmises(kappa,lambda,n)
% lambda is the skewing parameter, values in [-1,1]

X = circ_vmrnd(0,kappa,2*n);
B = (rand(2*n,1)<0.5*(1+lambda*sin(X)));
Y = X(B==1);

while length(Y)<n
    X = circ_vmrnd(0,kappa,n);
    B = (rand(n,1)<0.5*(1+lambda*sin(X)));
    Y = [Y;X(B==1)];
end
    
Y = Y(1:n);