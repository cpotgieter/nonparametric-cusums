
	function out=wrapped_stable(alpha,beta,mu,sigma,m,n);

	%function out=wrapped_stable(alpha,beta,mu,sigma,m,n);
	%
	% Matrix of random variates X from wrapped stable(alpha,beta,mu,sigma)distribution 
	% centred at mu with scale parameter sigma. beta is the skewness parameter
	% and alpha is the index of the stable distribution.
	% m=number of rows; n=number of columns
	% Example:
	% out=wrapped_stable(1,.5,0,2,1,1000) will generate a row vector of
	% 1000 random variates on the circle by wrapping 1000 random variates from
	% a Cauchy distribution (alpha=1) on the real line, centered at mu=0 with skewness
	% parameter beta=0.5 and scale parameter sigma=2.
	%
	% See Nolan (2015) pages 8 and 21 for Monte Carlo generation of stable variates


	onepi=pi;twopi=2*onepi;halfpi=onepi/2;
	THETA=onepi*(rand(m,n)-.5);    
	W=-log(rand(m,n));
	theta_0=atan(beta*tan(halfpi*alpha))/alpha;
	if alpha==1,
    		Z11=(halfpi+beta*THETA).*tan(THETA);
    		Z12=beta*(log(halfpi*W.*cos(THETA))-log(halfpi+beta*THETA));
    		Z=(Z11-Z12)/halfpi;
	else
    		Z11=sin(alpha*(THETA+theta_0))./(cos(alpha*theta_0)*cos(THETA)).^(1/alpha);
    		Z12=(cos((alpha-1)*THETA+alpha*theta_0)./W).^((1-alpha)/alpha);
    		Z=Z11.*Z12;
	end

	Y=mu+sigma*Z; % shift and rescale Z as desired
	theta=mod(Y,twopi);% wrap around the circle

	out=atan2(sin(theta),cos(theta));

    
 