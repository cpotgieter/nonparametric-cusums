function out = wrapped_skewt(xi,omega,lambda,df,n,m)

%function out = wrapped_skewt(xi,omega,lambda,df,n,m)
%
% xi is a real-valued location parameter
% omega is a positive scale parameter
% df is the degrees of freedom (inf for skew-normal)
% lambda is a real-valued skewness parameter

delta = lambda/sqrt(1+lambda.^2);

if df == inf                    % Gaussian distribution 
    r = delta*abs(randn(n,m))+sqrt(1-delta^2)*randn(n,m);
else                            % t-distribution with df degrees of freed.                       
    r = delta*abs(randn(n,m))+sqrt(1-delta^2)*randn(n,m);
    r = r./sqrt(chi2rnd(df,n,m));
          
end
    

r = xi + omega*r; % Scale and shift

S=sin(r);C=cos(r);
out=atan2(S,C);

end