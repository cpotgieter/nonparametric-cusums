function Y = sine_skew_wc(gamma,lambda,n)
% lambda is the skewing parameter, values in [-1,1]

r = gamma*trnd(1,2*n,1);
S=sin(r);C=cos(r);
X=atan2(S,C);
B = (rand(2*n,1)<0.5*(1+lambda*sin(X)));
Y = X(B==1);

while length(Y)<n
    r = gamma*trnd(1,n,1);
    S=sin(r);C=cos(r);
    X=atan2(S,C);
    B = (rand(n,1)<0.5*(1+lambda*sin(X)));
    Y = X(B==1);
    Y = [Y;X(B==1)];
end
    
Y = Y(1:n);