function [kappa_out,fval] = sine_skew_vm_concentration(concentration,lambda)

A = Akappa(concentration);

%options = optimset('Display','off');
[kappa_out,fval] = fsolve(@(k) rho_eval(k,lambda)-A,concentration);

if abs(fval)>10^(-5)
    kappa_out = nan;
end

end

function A=Akappa(kappa)

A=besseli(1,kappa)./besseli(0,kappa);

end

function rho = rho_eval(kappa,lambda)

I1_ratio = besseli(1,kappa)./besseli(0,kappa);
I2_ratio = besseli(2,kappa)./besseli(0,kappa);

rho = sqrt(I1_ratio.^2 + 0.25*lambda.^2.*(1-I2_ratio).^2);

end