function Y = sine_skew_cardioid(k,lambda,n)
% lambda is the skewing parameter, values in [-1,1]

X = circ_cardioid(k,2*n);
B = (rand(2*n,1)<0.5*(1+lambda*sin(X)));
Y = X(B==1);

while length(Y)<n
    X = circ_cardioid(k,n);
    B = (rand(n,1)<0.5*(1+lambda*sin(X)));
    Y = [Y;X(B==1)];
end
    
Y = Y(1:n);