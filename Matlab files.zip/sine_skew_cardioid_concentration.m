function [k_out,fval] = sine_skew_cardioid_concentration(concentration,lambda)

A = Akappa(concentration);

options = optimset('Display','off');
[k_out,fval] = fsolve(@(k) rho_eval(k,lambda)-A,concentration,options);

if abs(fval)>10^(-5)
    k_out = nan;
end

end

function A=Akappa(kappa)

A=besseli(1,kappa)./besseli(0,kappa);

end

function rho = rho_eval(k,lambda)

rho = 0.5*sqrt(k.^2+lambda.^2);

end