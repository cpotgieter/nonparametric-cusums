function [gamma_out,fval] = sine_skew_wc_concentration(concentration,lambda)

A = Akappa(concentration);

options = optimset('Display','off');
[gamma_out,fval] = fsolve(@(gamma) rho_eval(gamma,lambda)-A,concentration,options);

if abs(fval)>10^(-4)
    gamma_out = nan;
end

end

function A=Akappa(kappa)

A=besseli(1,kappa)./besseli(0,kappa);

end

function rho = rho_eval(gamma,lambda)

a1 = exp(-gamma);
a2 = exp(-2*gamma);
rho = sqrt(a1.^2+0.25*lambda.^2.*(1-a2).^2);

end