function Y = circ_cardioid(k,n)

%grid = linspace(-pi,pi,10^5);
%F = 0.5 + 0.5/pi*(grid+k*sin(grid));

M = 1+abs(k);
count = 0;

while count < n
    X = 2*pi*(rand-0.5);
    U = rand;
    if U<(1+k*cos(X))/M
        count = count + 1;
        Y(count,1) = X;
    end
end

end